#ifndef _BLINK_LED_
#define _BLINK_LED_

#include "MKL46Z4.h"

#define GREEN_LED_ON      GPIOD->PCOR |= (1 << 5)
#define GREEN_LED_OFF     GPIOD->PSOR |= (1 << 5)
#define RED_LED_ON    GPIOE->PCOR |= (1 << 29)
#define RED_LED_OFF   GPIOE->PSOR |= (1 << 29)

#define SECOND    4200000UL

/************************************************************
 *               function: void initLed()
 *               - init parameter for led red and green
************************************************************/
void initLed();

/************************************************************
 *               function:delay(uint32_t time)
 *               -use loop for to delay  the time
************************************************************/
void delay(uint32_t time);

/************************************************************
 *  function:void pwmLedGreen(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led green
************************************************************/
void pwmLedGreen(uint32_t cycle,uint8_t percent);

/************************************************************
 *  function:void pwmLedRed(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led red
************************************************************/
void pwmLedRed(uint32_t cycle,uint8_t percent);

/************************************************************
 *  function:void dimLed(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led green and red
************************************************************/
void dimLed(uint32_t cycle,uint8_t percent);

#endif