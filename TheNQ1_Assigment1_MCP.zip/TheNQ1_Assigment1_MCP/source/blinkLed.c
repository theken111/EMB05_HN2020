#include "blinkLed.h"

/************************************************************
 *               function: void initLed()
 *               - init parameter for led red and green
************************************************************/
void initLed()
{
    /* Enable clock for PORTD, PORTE */
    SIM->SCGC5 |= (1 << 12);    /* Set bit 12 */
    SIM->SCGC5 |= (1 << 13);    /* Set bit 13 */

    /* Configure multiplex of PTD5 and PTE29 as GPIO */
    PORTD->PCR[5] |= PORT_PCR_MUX(1);
    PORTE->PCR[29] |= PORT_PCR_MUX(1);

    /* Configure PTD5 and PTE29 as output */
    GPIOD->PDDR |= (1 << 5);
    GPIOE->PDDR |= (1 << 29);

    /* Clear PTD5 and PTE29 */
    RED_LED_ON;
    GREEN_LED_ON;
}

/************************************************************
 *               function:delay(uint32_t time)
 *               -use loop for to delay  the time
************************************************************/
void delay(uint32_t time)
{
    uint32_t i;

    for (i = 0; i < time; i++)
    {
        __asm("nop");
    }
}

/************************************************************
 *  function:void pwmLedGreen(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led green
************************************************************/
void pwmLedGreen(uint32_t cycle,uint8_t percent)
{
        uint8_t i;
        for(i=0;i<100;++i)
        {
            GREEN_LED_ON;
            delay(percent* cycle/10000);
            GREEN_LED_OFF;
            delay(cycle/100-percent* cycle/10000);
        }
}
/************************************************************
 *  function:void pwmLedRed(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led red
************************************************************/
void pwmLedRed(uint32_t cycle,uint8_t percent)
{
        uint8_t i;
        for(i=0;i<100;++i)
        {
            RED_LED_ON;
            delay(percent* cycle/10000);
            RED_LED_OFF;
            delay(cycle/100-percent* cycle/10000);
        }
}

/************************************************************
 *  function:void dimLed(uint32_t cycle,uint8_t percent)
 *  -pwm for pin led green and red
************************************************************/
void dimLed(uint32_t cycle,uint8_t percent)
{
    RED_LED_ON;
    GREEN_LED_OFF;
    delay(percent* cycle/100);
    GREEN_LED_ON;
    RED_LED_OFF;
    delay(cycle-percent* cycle/100);
}
