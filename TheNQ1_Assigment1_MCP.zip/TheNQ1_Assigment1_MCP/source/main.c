#include "blinkLed.h"

void main()
{
    initLed();

    while (1)
    {
        uint8_t i;
        uint8_t j;
        /*led on and off 10 time in 5 second*/
        for(i=0;i<10;i++)
        {
            RED_LED_OFF;
            pwmLedGreen(SECOND/4,50);

            GREEN_LED_OFF;
            pwmLedRed(SECOND/4,50);
        }
        /*pwm led from 1 to 100 and 100 to 1, 5 time in 5 s*/
        for(i=0;i<5;++i)
        {
            for(j=0;j<=100;j+=2)
            {
                dimLed(SECOND/2/50,j);
            }
            for(j=100;j>0; j-=2)
            {
                dimLed(SECOND/2/50,j);
            }
        }
    }
}

