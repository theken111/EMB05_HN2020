#include "HALOpenFile.h"
#include"HALReadSector.h"


int main() {
    int i;
    bootS bsd;
    open();
    bsd=bootSector();
	printf("oem: %s %d  %d  %d \n",bsd.OEM_Name,bsd.numSector,bsd.sizeSector,bsd.sizeCluster);
	fseek( fp, 0, SEEK_SET );
	
    for(i=0;i<26;++i)
    {
	    fread(buf,  1, line, fp);
     	printf("data: %s\n",buf);
	}
	printf("\nDirectory:\n");
	dirRoot();
	
    fclose(fp);
    return 0;
}




