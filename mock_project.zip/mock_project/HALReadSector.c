#include"HALReadSector.h"


uint16_t line=16;
uint8_t buf[512];

bootS bootSector(void)
{
    bootS bsd;
	int i;
	fseek( fp, 0, SEEK_SET );
	fread(buf, 1, line, fp);
	/*get OEM name*/
	for(i=0;i<8;i++)
	{
		bsd.OEM_Name[i]=buf[i+3];
	}
	bsd.sizeSector=FUSION(buf[11],buf[12]);
	bsd.sizeCluster=buf[13];
	fread(buf, 1, line, fp);
	printf("--- %s   %x, %x ---",buf,buf[3],buf[4]);
	bsd.numSector=FUSION(buf[3],buf[4]);

	return bsd;
}
void dirRoot(void)
{
    uint32_t i;
    uint8_t nameFile[8];
    uint8_t exFile[3];
    uint8_t attFile;
    uint16_t timeFile;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint32_t fileSize;
    uint32_t dayFile;
    uint8_t day;
    uint8_t month;
    uint16_t year;

    fseek( fp, 19*512, SEEK_SET );
    fread(buf, 2, line, fp);
    while(buf[0]!=0)
    {
        if(buf[31]!=255)
        {

            /*file name*/
            for(i=0;i<7;i++)
            {
                nameFile[i]=buf[i];
            }
            /*file extension*/
            for(i=7;i<10;++i)
            {
               exFile[i-7]=buf[i];
            }
            /*file time*/
            timeFile=FUSION(buf[0x0E],buf[0x0F]);
            //printf("t: %x |",timeFile);
            hour=(timeFile >> 11);
            printf("t: %d |",hour);
            min=0x3F&(timeFile>>5);
            sec=(timeFile & 0x1F)<<1;
            
            dayFile=FUSION(buf[0x10],buf[0x11]);
            //printf("t: %x |",timeFile);
            year=(dayFile >> 9)+1980;
            month=0x0F&(timeFile>>5);
            day=(timeFile & 0x1F);
            fileSize=SIZEFUSION(buf[28],buf[29],buf[30],buf[31]);

        printf("----  %s   %s size: %d  %d - %d - %d  %d - %d - %d\n",nameFile,exFile,fileSize,hour,min,sec,
        year,month ,day);
        }
        fread(buf, 2, line, fp);
    }


}
