#ifndef _HAL_READ_SECTOR_H_
#define _HAL_READ_SECTOR_H_

#include "HALOpenFile.h"

#define FUSION(a,b) (a|(b<<8))
#define SIZEFUSION(a,b,c,d) (a|(b<<8)|(c<<16)|(d<<24))

struct bootSector{
    uint8_t OEM_Name[8];
    uint16_t sizeSector;
    uint8_t sizeCluster;
    uint16_t numSector;

};


typedef struct bootSector bootS;
//typedef struct bootSector dirS;

extern uint16_t line;
extern uint8_t buf[512];

uint16_t multiHexToNum(uint8_t hex,uint8_t hexNext);

bootS bootSector(void);
void dirRoot(void);

#endif
