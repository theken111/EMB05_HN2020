#include "MKL46Z4.h"

#define GREEN_LED_ON      GPIOD->PCOR |= (1 << 5)
#define GREEN_LED_OFF     GPIOD->PSOR |= (1 << 5)
#define RED_LED_ON    GPIOE->PCOR |= (1 << 29)
#define RED_LED_OFF   GPIOE->PSOR |= (1 << 29)

#define DELAY_SECOND    1000000UL
#define DELAY_MSECOND    1000UL

void initLed();
void delay();
void duty(int pin,int duty,int percent);

void main()
{
    initLed();
    
    while (1)
    {
         int i=0;
         for(i=0;i<5;++i)
         {
             duty(1,DELAY_SECOND/2,10);
             duty(2,DELAY_SECOND/2,10);
             
         }
         
         for(i=0;i<10;++i)
         {
             int j;
             for(j=1;j<=100;++j)
             {
                  duty(1,DELAY_SECOND/2/100,j);
                  
             }
             for(j=1;j<=100;++j)
             {
                  duty(2,DELAY_SECOND/2/100,j);
                  
             }              
         }        
        
    }
}

void initLed()
{
    /* Enable clock for PORTD, PORTE */
    SIM->SCGC5 |= (1 << 12);    /* Set bit 12 */
    SIM->SCGC5 |= (1 << 13);    /* Set bit 13 */
    
    /* Configure multiplex of PTD5 and PTE29 as GPIO */
    PORTD->PCR[5] |= PORT_PCR_MUX(1);
    PORTE->PCR[29] |= PORT_PCR_MUX(1);
    
    /* Configure PTD5 and PTE29 as output */
    GPIOD->PDDR |= (1 << 5);
    GPIOE->PDDR |= (1 << 29);
    
    /* Clear PTD5 and PTE29 */
    RED_LED_ON;
    GREEN_LED_ON;
}

void delay(unsigned long time)
{
    unsigned long i;
    
    for (i = 0; i < time; i++)
    {
        __asm("nop");
    }
}
void duty(int pin,int duty, int  percent)
{    
      
     if(pin==1)
     {
          int j;
          for(j=0;j<50;j++)
          {
              GREEN_LED_ON;
              RED_LED_OFF;
              delay(duty*percent/100);
              GREEN_LED_OFF;
              RED_LED_ON;
              delay(duty-duty*percent/100);
          }        
          
     } 
     else if(pin==2)
     {
          int j;
          for(j=0;j<50;j++)
          {
              GREEN_LED_OFF;
              RED_LED_ON;
              delay(duty*percent/100);
              GREEN_LED_ON;
              RED_LED_OFF;
              delay(duty-duty*percent/100);
          }       
     } 
}  