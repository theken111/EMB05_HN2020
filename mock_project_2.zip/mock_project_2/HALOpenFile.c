#include "HALOpenFile.h"

void open(void)
{
	fp=fopen("floppy.img","rb");

    if(fp == NULL)
    {
       printf("Error!");
       exit(1);
    }
}

