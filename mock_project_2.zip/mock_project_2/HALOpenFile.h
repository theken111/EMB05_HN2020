#ifndef _HAL_OPENFILE_H_
#define _HAL_OPENFILE_H_

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<stdint.h>
#include<string.h>

FILE *fp;
void open(void);


#endif
