#include "HALOpenFile.h"
#include"HALReadSector.h"


int main() {
    int i;
    bootS bsd;
    open();
    bsd=bootSector();
	printf("oem: %s %d  %d  %d \n",bsd.OEM_Name,bsd.numSector,bsd.sizeSector,bsd.sizeCluster);
	fseek( fp, 0, SEEK_SET );

    readAllFile(8);

    //menu();
//	fflush(stdin);
//	printf("\n");
//	readFile(34,51);
//	printf("\n");
//	readFile(33,51);
//	printf("\n");
//    readFile(35,51);
//    printf("\n");
//    readFile(36,51);	
//	
	fclose(fp);
    return 0;
}




