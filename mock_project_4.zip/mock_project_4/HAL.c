#include "HAL.h"

void open(void)
{
	fp=fopen("floppy.img","rb");

    if(fp == NULL)
    {
       printf("Error!");
       exit(1);
    }
}

void closeFile(void)
{
    fclose(fp);
}
void readSector(uint16_t headSector)
{
    fseek( fp, 0, SEEK_SET );
	fread(buf, 1, line, fp);
}
void readCluster(uint16_t headClustertor)
{
    
}
