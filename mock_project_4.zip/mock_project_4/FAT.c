#include"FAT.h"


uint16_t line=16;
uint16_t sector=512;
uint8_t buf[512];
uint8_t fatArr[4608];

/************************************************************
		function: bootS bootSector(void)
		target  : read data at reverse area
************************************************************/
void bootSector(void)
{
    bootSector boot;
	int i;
	fseek( fp, 0, SEEK_SET );
	fread(buf, 1, line, fp);
	/*get OEM name*/
	for(i=0;i<8;i++)
	{
		bsd.OEM_Name[i]=buf[i+3];
	}
	bsd.sizeSector=READ_2_BYTE(buf[11],buf[12]);
	bsd.sizeCluster=buf[13];
	fread(buf, 1, line, fp);
	bsd.numSector=READ_2_BYTE(buf[3],buf[4]);

    printf("oem: %s %d  %d  %d \n",bsd.OEM_Name,bsd.numSector,bsd.sizeSector,
    bsd.sizeCluster);
}

/************************************************************
		function: void dirRoot(void)
		target  : read data at directory area
************************************************************/

uint16_t dirRoot(uint16_t nextAddr)
{
    uint32_t count=0;
    uint16_t timeFile;
    uint8_t i;
    uint32_t dayFile;
    uint32_t retAddr;
    fileAttr file;
    uint8_t choice;
    uint16_t next;
    uint16_t row=0;
    fseek( fp, nextAddr*512, SEEK_SET );
    fread(buf, 1, sector, fp);
    

    while(buf[0+count]!=0)
    {
        if(buf[31+count]!=255)
        {

            /*file name*/
            for(i=0;i<7;i++)
            {
                file.name[i]=buf[i+count];
            }
            /*file extension*/
            for(i=7;i<10;++i)
            {
               file.extension[i-7]=buf[i+count];
            }
            /*file time*/
            timeFile=READ_2_BYTE(buf[14+count],buf[15+count]);
            //printf("t: %x |",timeFile);
            file.hour=(timeFile >> 11);
             
            file.min=0x3F&(timeFile>>5);
            file.sec=(timeFile & 0x1F)<<1;
            
            dayFile=READ_2_BYTE(buf[16+count],buf[17+count]);
            //printf("t: %x |",timeFile);
            file.year=(dayFile >> 9)+1980;
            file.month=0x0F&(timeFile>>5);
            file.day=(timeFile & 0x1F);
            file.nextAddr=READ_2_BYTE(buf[26+count],buf[27+count]);
            
            //boot sector + fat + root directory + start addr-2
            next=19+224*32/512+(file.nextAddr-2);
            file.size=SIZEREAD_2_BYTE(buf[28],buf[29],buf[30],buf[31]);

        printf("---------%d  %s   %s size: %d  %d - %d - %d  %d - %d - %d"
         "--------\n",row,file.name,file.extension,file.size,file.hour,file.min,
         file.sec,file.year,file.month ,file.day);
        
            
        }
        row+=1;
        count+=32;
    }
    printf("\nNext:");
    fflush(stdin);
    scanf("%d",&choice);
    retAddr=0x21+READ_2_BYTE(buf[(choice*32)+26 ],buf[(choice*32)+27 ])-0x02;

    if(retAddr==31)
    {
        retAddr=19;
    }
    
	return retAddr;

}
/************************************************************
		function: void readFile(uint16_t startAdress, uint32_t sizeFile)
		target  : read data in a file 
************************************************************/
 
void readFile(uint16_t startAddress, uint32_t sizeFile)
{   
 
	fseek( fp, startAddress*512, SEEK_SET );
	int32_t i;
	//fread(buf, 1, line, fp);
    for(i=0;i<=sizeFile/line ;++i)
    {    	
    	fread(buf, 1, line, fp);
        printf("%s",buf);
	}    
}
void menu(void)
{
    uint16_t nextAddr=19;
    while(1)
    {
        nextAddr=dirRoot(nextAddr);
    }
}
/***********************************************
           function: read long file
           
************************************************/
void readAllFile(uint16_t startAddr)
{
    uint16_t nextAddr;
    uint16_t startCluster= 0x21+ startAddr - 0x02;
    nextAddr=startAddr;
    do{
    	int32_t j;
    //for(j=0;j<15;++j)
    
        int32_t i;
    	fseek( fp, (startCluster)*512, SEEK_SET );
    	fread(buf, 1, sector, fp);
        for(i=0;i<512 ;++i)
        {
            printf("%c",buf[i]);
       	}
       	nextAddr=findNext(nextAddr);
       	startCluster=0x21+ nextAddr -0x02;
    	
    }while(nextAddr!=0xFFF);
}
uint16_t  findNext(uint16_t startAddr)
{
    uint16_t nextAddr;
    fseek( fp, 1*512, SEEK_SET );
    fread(fatArr, 9, sector, fp);
    if(startAddr%2==0)
    {
        nextAddr=((fatArr[(startAddr*3/2 +1)]&0xFu)<<8)|fatArr[(startAddr*3/2)];
    }
    else
    {
        nextAddr=((fatArr[startAddr*3/2]>>4)|(fatArr[startAddr*3/2+1]<<4));
    }
    return nextAddr;
}

