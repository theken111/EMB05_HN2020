#ifndef _FAT_H_
#define _FAT_H_

#include "HAL.h"

#define READ_2_BYTE(a,b) (a|(b<<8))
#define READ_4_BYTE(a,b,c,d) (a|(b<<8)|(c<<16)|(d<<24))

struct bootSector{
    uint8_t OEM_Name[8];
    uint16_t sector;
    uint8_t sectorPerCluster;
    uint8_t numFat;
    uint16_t numRootDir;
    uint16_t numSector;
    uint16_t sizeFat;

};

struct fileAttribute{
    uint8_t name[8];
    uint8_t extension[3];
    uint8_t attribute;
    uint16_t nextAddr;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint32_t size;    
    uint8_t day;
    uint8_t month;
    uint16_t year;
};

typedef struct fileAttribute fileAttr;
//typedef struct bootSector dirS;

extern uint16_t line;
//extern uint16_t sector;

extern uint8_t fatArr[4608];

uint16_t multiHexToNum(uint8_t hex,uint8_t hexNext);

void bootSector(void);
uint16_t dirRoot(uint16_t nextAddr);
void readFile(uint16_t startAdress, uint32_t sizeFile);
void menu(void);
void fatTable();
uint16_t  findNext(uint16_t startAddr);

#endif
