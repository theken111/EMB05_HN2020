#include"FAT.h"


int main() {
    int i;
    bootS bsd;
    open();
    
    bootSector();


    //readAllFile(1260);

    menu();
//	fflush(stdin);
//	printf("\n");
//	readFile(34,51);
//	printf("\n");
//	readFile(33,51);
//	printf("\n");
//    readFile(35,51);
//    printf("\n");
//    readFile(36,51);	
//	
	closeFile();
    return 0;
}




